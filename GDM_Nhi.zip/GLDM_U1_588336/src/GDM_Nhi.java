import ij.ImageJ;
import ij.ImagePlus;
import ij.gui.GenericDialog;
import ij.gui.NewImage;
import ij.plugin.PlugIn;
import ij.process.ImageProcessor;

//erste Uebung (elementare Bilderzeugung)

public class GDM_Nhi implements PlugIn {

    final static String[] choices = {
            "Schwarzes Bild",
            "Belgische Fahne",
            "Schwarz/Weiss Verlauf",
            "W/S Verlauf Diagonal",
            "Horiz. Schwarz/Rot vert. Schwarz/Blau Verlauf",
            "USA Fahne",
            "Tchechische Fahne"
    };

    private String choice;

    public static void main(String args[]) {
        ImageJ ij = new ImageJ(); // neue ImageJ Instanz starten und anzeigen
        ij.exitWhenQuitting(true);

        GDM_Nhi imageGeneration = new GDM_Nhi();
        imageGeneration.run("");
    }

    public void run(String arg) {

        int width  = 566;  // Breite
        int height = 400;  // Hoehe

        // RGB-Bild erzeugen
        ImagePlus imagePlus = NewImage.createRGBImage("GLDM_U1", width, height, 1, NewImage.FILL_BLACK);
        ImageProcessor ip = imagePlus.getProcessor();

        // Arrays fuer den Zugriff auf die Pixelwerte
        int[] pixels = (int[])ip.getPixels();

        dialog();

        ////////////////////////////////////////////////////////////////
        // Hier bitte Ihre Aenderungen / Erweiterungen

        if ( choice.equals("Schwarzes Bild") ) {
            generateBlackImage(width, height, pixels);
        }
        if ( choice.equals("Belgische Fahne") ) {
            generateBelgianFlag(width, height, pixels);
        }
        if ( choice.equals("Schwarz/Weiss Verlauf") ) {
           generateHoriVerlauf(width, height, pixels);
        }
        if ( choice.equals("W/S Verlauf Diagonal") ) {
            generateDiaVerlauf(width, height, pixels);
        }
        if ( choice.equals("Horiz. Schwarz/Rot vert. Schwarz/Blau Verlauf") ) {
            generateBigVerlauf(width, height, pixels);
        }
        if ( choice.equals("USA Fahne") ) {
            generateUSA(width, height, pixels);
        }
        if ( choice.equals("Tchechische Fahne") ) {
            generateCzech(width, height, pixels);
        }

        ////////////////////////////////////////////////////////////////////

        // neues Bild anzeigen
        imagePlus.show();
        imagePlus.updateAndDraw();
    }

    private void generateBlackImage(int width, int height, int[] pixels) {
        // Schleife ueber die y-Werte
        for (int y=0; y<height; y++) {
            // Schleife ueber die x-Werte
            for (int x=0; x<width; x++) {
                int pos = y*width + x; // Arrayposition bestimmen

                int r = 0;
                int g = 0;
                int b = 0;

                // Werte zurueckschreiben
                pixels[pos] = 0xFF000000 | (r << 16) | (g << 8) |  b;
            }
        }
    }

    private void generateBelgianFlag(int width, int height, int[] pixels) {
        int thirdWidth = width / 3; //teilt in 3 components für 3 farben

        // Schleife ueber die y-Werte
        for (int y = 0; y < height; y++) {
            // Schleife ueber die x-Werte
            for (int x = 0; x < width; x++) {
                int pos = y * width + x; // Arrayposition bestimmen

                int r, g, b;

                // welche farbe an welcher position?
                if (x < thirdWidth) {
                    r = 0;
                    g = 0;
                    b = 0; // 0= schwarz
                } else if (x < 2 * thirdWidth){
                    r = 255;
                    g = 215;
                    b = 0; // gelb
                } else {
                    r = 255;
                    g = 0;
                    b = 0; // rot
                }

                // Werte zurueckschreiben
                pixels[pos] = 0xFF000000 | (r << 16) | (g << 8) | b;
            }
        }
    }

    private void generateHoriVerlauf(int width, int height, int[] pixels) {
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int pos = y * width + x;

                double t = x / (double) width; // Interpolieren parameter

                int r = (int) (255 * t);
                int g = (int) (255 * t);
                int b = (int) (255 * t);

                pixels[pos] = 0xFF000000 | (r << 16) | (g << 8) |  b;
            }
        }
    }

    private void generateDiaVerlauf(int width, int height, int[] pixels) {
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int pos = y * width + x;

                double t = y/ (double) height; // Interpolieren parameter

            //Interpolation umkehren damit erst weiß und dann schwarz wird
                int r = (int) (255 * (1 - t));
                int g = (int) (255 * (1 - t));
                int b = (int) (255 * (1 - t));

                pixels[pos] = 0xFF000000 | (r << 16) | (g << 8) |  b;
            }
        }
    }

    //Schwarz Rot Schwarz Blau = Rio Filter
   private void generateBigVerlauf(int width, int height, int[] pixels) {
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int pos = y * width + x;

                double tHori = x / (double) width; // Interpolieren parameter Horizontal
                double tDia = y / (double) height; // Interpolieren parameter Diagonal


                //Horiz. Verlauf zwischen Schwarz und Rot
                int rHori = (int) (255 * tHori); //Nur rot opak machen
                int gHori = 0; //schwarz
                int bHori = 0;

                // Diag. Verlauf zwischen Schwarz & Blau

                int rDia = (int) (0 * (1-tDia)); //Nur rot opak machen
                int gDia= (int) (0 * (1-tDia));
                int bDia = (int) (255 * (1-tDia));

                //Combine HOriz. mit Diag.

                int rAll= (rHori + rDia) / 2;
                int gAll= (gHori + gDia) /2;
                int bAll= (bHori+ bDia) /2;

                pixels[pos] = 0xFF000000 | (rAll << 16) | (gAll << 8) |  bAll;
            }
        }
    }

    // Für die Aufgabe habe ich ChatGPT nach Ideen gefragt wie man das lösen könnte
    private void generateUSA(int width, int height, int[] pixels) {
        int stripeHeight = height / 13; // Flaggen Streifen

        // Loop für die Reihen
        for (int y = 0; y < height; y++) {
            // Streifen index
            int stripeIndex = y / stripeHeight;

            // Loop für Spalte
            for (int x = 0; x < width; x++) {
                int pos = y * width + x;

                // Ist es blau?
                if (x < (width * 2 / 5) && y < (stripeHeight * 7)) {
                    // Blaues Rechteck
                    pixels[pos] = 0xFF001F3F; // Dunkelblau
                } else {
                    // Streifen
                    int r = 255;
                    int g = 255;
                    int b = 255;

                    // Wenn gerader Streifen = Weiß
                    if (stripeIndex % 2 == 0) {
                        pixels[pos] = 0xFFFFFFFF;
                    } else {
                        pixels[pos] = 0xFFB22234; // Rot
                    }
                }
            }
        }
    }


    private void generateCzech(int width, int height, int[] pixels) {
        int stripeHeight = height / 2; // Flaggen Streifen

        // Loop für die Reihen
        for (int y = 0; y < height; y++) {
            // Streifen index
            int stripeIndex = y / stripeHeight;

            // Loop für Spalte
            for (int x = 0; x < width; x++) {
                int pos = y * width + x;

                // blaues dreieck
                int threshold = (y * width) / height;
                if (x <= threshold && x <= width - threshold) {
                    int blue = 0x002868;
                    pixels[pos] = 0xFF000000 | blue;
                } else {
                    // Streifen
                    int r = 255;
                    int g = 255;
                    int b = 255;

                    // Wenn gerader Streifen = Weiß
                    if (stripeIndex % 2 == 0) {
                        pixels[pos] = 0xFFFFFFFF;
                    } else {
                        pixels[pos] = 0xFFB22234; // Rot
                    }
                }
            }
        }
    }




    private void dialog() {
        // Dialog fuer Auswahl der Bilderzeugung
        GenericDialog gd = new GenericDialog("Bildart");

        gd.addChoice("Bildtyp", choices, choices[0]);


        gd.showDialog();	// generiere Eingabefenster

        choice = gd.getNextChoice(); // Auswahl uebernehmen

        if (gd.wasCanceled())
            System.exit(0);
    }
}
